import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(__dirname));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY), aiModel: process.env.AI_MODEL || 'gpt-5.5' });
});

app.post('/api/generate', async (req, res) => {
  try {
    const { mode, text, subject = '', count = 10, questionType = 'mixed', difficulty = 'medium', filename = '' } = req.body || {};
    if (typeof text !== 'string' || text.trim().length < 80) {
      return res.status(400).json({ error: 'أضف نص محاضرة لا يقل عن 80 حرفًا.' });
    }
    if (text.length > 100000) return res.status(413).json({ error: 'النص طويل جدًا؛ قسّمه إلى أجزاء أصغر.' });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'مفتاح OpenAI API غير مضبوط في ملف .env. قد تكون خدمة API مدفوعة بشكل منفصل.' });

    const instructions = {
      exam: `أنشئ امتحانًا تعليميًا باللغة العربية من محتوى المحاضرة. المادة: ${subject || 'غير محددة'}. عدد الأسئلة المطلوب: ${Math.max(1, Math.min(40, Number(count) || 10))}. النوع: ${questionType}. الصعوبة: ${difficulty}. اكتب الأسئلة والاختيارات ثم نموذج الإجابة مع تفسير موجز في قسم منفصل بعد الأسئلة. لا تضف معلومات غير مدعومة بالمصدر.`,
      summary: `اكتب ملخصًا عربيًا منظمًا ودقيقًا للمحاضرة، بعناوين ونقاط وتعريفات وأهم العلاقات، ثم أضف مراجعة سريعة. لا تخترع معلومات غير موجودة.`,
      mindmap: `حوّل المحاضرة إلى خريطة ذهنية بصيغة Mermaid mindmap صالحة فقط، تبدأ بـ mindmap ثم root((عنوان المحاضرة)). اجعل التسميات قصيرة بالعربية، ولا تضع أي نص خارج كتلة الخريطة.`,
      flashcards: `أنشئ بطاقات مراجعة عربية بصيغة سؤال ثم جواب، مرقمة وواضحة، تغطي أهم الأفكار والتعريفات والعلاقات. لا تضف معلومات غير موجودة بالمصدر.`
    };
    if (!instructions[mode]) return res.status(400).json({ error: 'نوع التوليد غير معروف.' });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.AI_MODEL || 'gpt-5.5',
      instructions: instructions[mode],
      input: `اسم الملف: ${filename || 'غير محدد'}\n\nمحتوى المحاضرة:\n${text.trim()}`
    });
    res.json({ result: response.output_text || '' });
  } catch (err) {
    console.error('AI generation error:', err?.status || '', err?.message || err);
    res.status(500).json({ error: 'تعذر إنشاء المحتوى. راجع إعداد مفتاح API واسم النموذج ثم حاول مرة أخرى.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.listen(port, () => console.log(`DARS AI running at http://localhost:${port}`));
